"""Tile-based processing for large Sentinel-2 AOIs.

Features
--------
* Per-tile scene filtering (only scenes whose real footprint touches the tile).
* Deterministic run folder + atomic tile writes -> an interrupted run resumes.
* Optional process-level parallelism (``max_workers > 1``).
* AOI polygon clip applied to the final 2D result, not the full time stack.
* Per-tile valid-observation-count raster, mosaicked like the main product.
* Nodata value and COG predictor taken from the real tile files.
* Per-tile retries; failed tiles are reported and the run can be re-launched.

NOTE: with ``max_workers > 1`` the calling script MUST be guarded by
``if __name__ == "__main__":`` because worker processes are spawned.
"""

import gc
import hashlib
import json
import multiprocessing
import shutil
import subprocess
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

import dask
import numpy as np
import pystac
import rasterio
import rioxarray
from rasterio.features import geometry_mask
from pyproj import Transformer
from shapely.ops import transform as transform_geometry
from odc.stac import configure_s3_access
from rio_cogeo.cogeo import cog_validate
from shapely.geometry import shape

from eo.tiling import (
    build_aoi_tiles,
    build_single_aoi_window,
    choose_target_crs,
)
from eo.sentinel2 import load_sentinel2_items
from eo.masking import (
    mask_with_scl,
    count_valid_observations,
    normalize_retained_classes,
    excluded_classes_for,
)
from eo.composites import create_temporal_composite
from eo.processor import process_data
from eo.export import export_cog
from eo.metadata import create_metadata, save_metadata
from eo.previews import create_cog_preview, create_ndwi_preview


OUTPUT_NAMES = {
    "RGB": "rgb.tif",
    "FALSE_COLOR": "false_color.tif",
    "NDVI": "ndvi.tif",
    "NDWI": "ndwi.tif",
    "NDMI": "ndmi.tif",
    "NBR": "nbr.tif",
    "NBR2": "nbr2.tif",
}

SPECTRAL_BANDS = ["red", "green", "blue", "nir", "swir16", "swir22"]

COUNT_NODATA = 65535


def _mask_array_to_aoi(array, aoi_geometry):
    """Mask pixels outside an AOI using the array's own raster grid."""

    if array.rio.crs is None:
        raise ValueError("Cannot mask AOI: raster CRS is missing.")

    height = array.rio.height
    width = array.rio.width
    transform = array.rio.transform()
    raster_crs = array.rio.crs

    to_raster_crs = Transformer.from_crs(
        "EPSG:4326",
        raster_crs,
        always_xy=True,
    ).transform

    projected_geometry = transform_geometry(
        to_raster_crs,
        aoi_geometry,
    )

    inside = geometry_mask(
        [projected_geometry.__geo_interface__],
        out_shape=(height, width),
        transform=transform,
        all_touched=False,
        invert=True,
    )

    # Xarray applies the 2D mask to the matching 2D raster grid.
    return array.where(inside)


# GDAL settings that make thousands of public-S3 reads more robust.
GDAL_ENV = {
    "GDAL_HTTP_MAX_RETRY": "5",
    "GDAL_HTTP_RETRY_DELAY": "1",
    "GDAL_DISABLE_READDIR_ON_OPEN": "EMPTY_DIR",
    "GDAL_HTTP_MULTIPLEX": "YES",
}

# ------------------------------------------------------------
# Radiometric scaling
# ------------------------------------------------------------

def _scale_tile_from_metadata(data, items, tile_id):
    """Apply each loaded band's consistent STAC scale and offset."""

    for band_name in SPECTRAL_BANDS:
        if band_name not in data.data_vars:
            continue

        parameters = set()

        for item in items:
            asset = item.assets.get(band_name)

            if asset is None:
                raise RuntimeError(
                    f"{tile_id}: missing {band_name} asset "
                    f"in scene {item.id}."
                )

            raster_bands = asset.extra_fields.get("raster:bands") or []

            if not raster_bands:
                raise RuntimeError(
                    f"{tile_id}: missing raster:bands metadata "
                    f"for {band_name}, scene {item.id}."
                )

            meta = raster_bands[0]
            scale = meta.get("scale")
            offset = meta.get("offset", 0.0)
            nodata = meta.get("nodata", 0)

            if scale is None:
                raise RuntimeError(
                    f"{tile_id}: missing scale for {band_name}."
                )

            parameters.add((
                float(scale),
                float(0.0 if offset is None else offset),
                float(0.0 if nodata is None else nodata),
            ))

        if len(parameters) != 1:
            raise RuntimeError(
                f"{tile_id}: inconsistent scale, offset or NoData "
                f"metadata for {band_name}: {parameters}"
            )

        scale, offset, nodata = next(iter(parameters))

        raw = data[band_name]
        valid = raw.notnull() & (raw != nodata)

        data[band_name] = (
            raw.astype("float32") * scale + offset
        ).where(valid)

    return data


# ------------------------------------------------------------
# Single-tile worker (top-level so it can be pickled)
# ------------------------------------------------------------

def _atomic_export_cog(array, final_path):
    partial = final_path.with_name(final_path.stem + ".partial.tif")
    if partial.exists():
        partial.unlink()
    export_cog(array, partial)
    if not partial.is_file():
        raise RuntimeError(f"COG export did not create {partial}.")
    partial.replace(final_path)


def _write_count_raster(count, aoi_geometry, target_crs, final_path):
    """Write the per-pixel valid observation count as uint16 GeoTIFF."""

    if count.rio.crs is None:
        count = count.rio.write_crs(target_crs)

    count = _mask_array_to_aoi(
        count.astype("float32"),
        aoi_geometry,
    )

    count = (
        count.fillna(COUNT_NODATA)
        .astype("uint16")
        .rio.write_nodata(COUNT_NODATA, inplace=False)
    )

    partial = final_path.with_name(final_path.stem + ".partial.tif")
    if partial.exists():
        partial.unlink()

    count.rio.to_raster(
        partial,
        driver="GTiff",
        dtype="uint16",
        tiled=True,
        compress="DEFLATE",
    )
    partial.replace(final_path)


def _run_tile(task, items):
    tile = task["tile"]
    tile_id = tile["tile_id"]
    process = task["process"]
    target_crs = task["target_crs"]

    tile_file = Path(task["tile_file"])
    count_file = Path(task["count_file"]) if task["count_file"] else None

    started = time.perf_counter()

    load_started = time.perf_counter()

    data = load_sentinel2_items(
        items=items,
        geometry=None,
        requested_product=process,
        tile_bounds=tile["bounds"],
        target_crs=target_crs,
    )

    load_seconds = time.perf_counter() - load_started

    if data.rio.crs is None:
        raise RuntimeError(f"{tile_id}: loaded data has no CRS.")

    data = _scale_tile_from_metadata(data, items, tile_id)

    masked = mask_with_scl(
        data, retained_classes=task["scl_classes"]
    )

    bands = [b for b in SPECTRAL_BANDS if b in masked.data_vars]

    composite = create_temporal_composite(
        masked[bands],
        method=task["composite_method"],
    )

    result = process_data(composite, process)

    if result is None:
        raise RuntimeError(f"{tile_id}: {process} returned no result.")

    count = None
    if count_file is not None:
        count = count_valid_observations(masked, bands)

    # Compute the shared graph once so the S3 reads are not repeated.
    compute_started = time.perf_counter()

    # Fully masked pixels are expected around clouds and outside scene
    # coverage. NumPy may warn when a median pixel has no valid observations;
    # the final finite-pixel check below distinguishes that from an empty tile.
    import warnings
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message="All-NaN slice encountered",
            category=RuntimeWarning,
        )
        if count is not None:
            result, count = dask.persist(result, count)
        else:
            (result,) = dask.persist(result)

    compute_seconds = time.perf_counter() - compute_started

    if not bool(result.notnull().any().compute().item()):
        raise RuntimeError(
            f"{tile_id}: NO_VALID_PIXELS — {process} has no valid "
            "pixels after SCL masking and temporal compositing."
        )

    # Clip the final 2D product to the exact AOI polygon.
    if result.rio.crs is None:
        result = result.rio.write_crs(target_crs)

    clip_geometry = tile["aoi_geometry_wgs84"]
    result = _mask_array_to_aoi(result, clip_geometry)

    export_started = time.perf_counter()
    _atomic_export_cog(result, tile_file)
    export_seconds = time.perf_counter() - export_started

    wrote_count = False

    if count is not None:
        _write_count_raster(
            count,
            tile["aoi_geometry_wgs84"],
            target_crs,
            count_file,
        )
        wrote_count = True

    del data, masked, composite, result, count
    gc.collect()

    return {
        "tile_id": tile_id,
        "bounds": list(tile["bounds"]),
        "file": str(tile_file),
        "count_file": str(count_file) if wrote_count else None,
        "scenes_used": len(items),
        "elapsed_seconds": round(time.perf_counter() - started, 3),
        "export_seconds": round(export_seconds, 3),
        "load_setup_seconds": round(load_seconds, 3),
        "compute_seconds": round(compute_seconds, 3),
        "status": "completed",
    }


def _process_one_tile(task):
    """Process one tile with retries. Never raises; returns a record."""

    tile_id = task["tile"]["tile_id"]
    tile_file = Path(task["tile_file"])
    count_file = Path(task["count_file"]) if task["count_file"] else None

    # Resume: reuse completed outputs.
    if tile_file.is_file() and (count_file is None or count_file.is_file()):
        return {
            "tile_id": tile_id,
            "bounds": list(task["tile"]["bounds"]),
            "file": str(tile_file),
            "count_file": str(count_file) if count_file else None,
            "status": "reused",
        }

    configure_s3_access(aws_unsigned=True)

    items = [pystac.Item.from_dict(d) for d in task["item_dicts"]]

    last_error = None

    for attempt in range(1, task["retries"] + 1):
        try:
            with rasterio.Env(**GDAL_ENV):
                return _run_tile(task, items)
        except Exception as exc:  # noqa: BLE001 - report and retry
            last_error = exc
            for leftover in (tile_file, count_file):
                if leftover is None:
                    continue
                partial = leftover.with_name(leftover.stem + ".partial.tif")
                if partial.exists():
                    partial.unlink()
            time.sleep(2 * attempt)

    return {
        "tile_id": tile_id,
        "bounds": list(task["tile"]["bounds"]),
        "status": "failed",
        "error": f"{type(last_error).__name__}: {last_error}",
    }


# ------------------------------------------------------------
# Helpers for the parent process
# ------------------------------------------------------------

def _run_key(*, process, items, start_date, end_date, composite_method,
             cloud_cover_threshold, tile_size_m, target_crs, aoi_shape,
             scl_classes, processing_mode, max_window_size_m):
    """Stable hash so re-running identical inputs resumes the same folder."""
    payload = json.dumps(
        {
            "process": process,
            "clip_version": 3,
            "processing_mode": processing_mode,
            "max_window_size_m": max_window_size_m,
            "scenes": sorted(item.id for item in items),
            "start": str(start_date),
            "end": str(end_date),
            "method": composite_method,
            "cloud": float(cloud_cover_threshold),
            "tile_size": tile_size_m,
            "crs": str(target_crs),
            "aoi": aoi_shape.wkb_hex,
            "scl": list(scl_classes),
        },
        sort_keys=True,
    )
    return hashlib.sha1(payload.encode()).hexdigest()[:10]



def _portable_path(path, project_root):
    """Return a project-relative POSIX path without exposing local paths."""
    if path is None:
        return None

    path = Path(path)
    root = Path(project_root)

    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except (OSError, ValueError):
        # Match the fallback used by metadata file records.
        return path.name


def _write_manifest(path, header, records, status, *, project_root):
    """Write portable path references without changing internal tile records."""
    manifest = dict(header)
    manifest["status"] = status

    portable_records = []

    for record in records:
        portable_record = dict(record)

        for key in ("file", "count_file"):
            if portable_record.get(key):
                portable_record[key] = _portable_path(
                    portable_record[key],
                    project_root,
                )

        portable_records.append(portable_record)

    manifest["tiles"] = portable_records

    tmp = path.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as file:
        json.dump(manifest, file, indent=2)

    tmp.replace(path)



def _mosaic(files, vrt_file, output_file, *, nodata_arg, cog_options,
            gdalbuildvrt, gdal_translate):
    subprocess.run(
        [
            gdalbuildvrt,
            "-overwrite",
            "-srcnodata", nodata_arg,
            "-vrtnodata", nodata_arg,
            str(vrt_file),
            *[str(path) for path in files],
        ],
        check=True,
    )

    if output_file.exists():
        output_file.unlink()

    subprocess.run(
        [
            gdal_translate,
            "-of", "COG",
            *cog_options,
            str(vrt_file),
            str(output_file),
        ],
        check=True,
    )

    if not output_file.is_file():
        raise RuntimeError(f"Mosaic was not created: {output_file}")


# ------------------------------------------------------------
# Main entry point
# ------------------------------------------------------------

def process_tiled_aoi(
    *,
    items,
    aoi_shape,
    process,
    composite_method,
    start_date,
    end_date,
    cloud_cover_threshold,
    reference_item,
    output_dir,
    project_root,
    input_parameters,
    tile_size_m=5000,
    processing_mode="auto",
    max_window_size_m=10000,
    max_workers=2,
    tile_retries=3,
    write_valid_count=True,
    keep_tiles=True,
    scl_retained_classes=None,
):
    """Process an AOI using one window or multiple spatial tiles."""

    process = str(process).strip().upper()
    composite_method = str(composite_method).strip().lower()

    if process == "QUALITY_MASK":
        raise NotImplementedError(
            "QUALITY_MASK is not implemented by the current "
            "product dispatcher. Select another product."
        )

    if process not in OUTPUT_NAMES:
        raise ValueError(f"Unsupported product: {process}")

    if not items:
        raise ValueError("No Sentinel-2 scenes were supplied.")

    max_workers = max(1, int(max_workers))
    scl_classes = normalize_retained_classes(scl_retained_classes)

    output_dir = Path(output_dir)
    project_root = Path(project_root)
    output_dir.mkdir(parents=True, exist_ok=True)

    gdalbuildvrt = shutil.which("gdalbuildvrt")
    gdal_translate = shutil.which("gdal_translate")

    if not gdalbuildvrt or not gdal_translate:
        raise RuntimeError(
            "gdalbuildvrt and gdal_translate are required. "
            "Install GDAL tools and ensure both are on PATH."
        )

    target_crs = choose_target_crs(items, aoi_shape)

    requested_mode = str(processing_mode).strip().lower()
    if requested_mode not in {"auto", "single_window", "tiled"}:
        raise ValueError(
            "processing_mode must be 'auto', 'single_window', or 'tiled'."
        )

    if (
        isinstance(max_window_size_m, bool)
        or not isinstance(max_window_size_m, (int, float))
        or max_window_size_m <= 0
    ):
        raise ValueError("max_window_size_m must be a positive number.")

    max_window_size_m = float(max_window_size_m)

    window_tiles = []
    if requested_mode in {"auto", "single_window"}:
        window_tiles = build_single_aoi_window(
            aoi_shape,
            target_crs=target_crs,
            max_window_size_m=max_window_size_m,
        )

    if window_tiles:
        tiles = window_tiles
        actual_mode = "single_window"
    elif requested_mode == "single_window":
        raise ValueError(
            "AOI exceeds max_window_size_m in at least one dimension. "
            "Increase max_window_size_m or use processing_mode='auto' "
            "or 'tiled'."
        )
    else:
        tiles = build_aoi_tiles(
            aoi_shape,
            tile_size_m=tile_size_m,
            target_crs=target_crs,
        )
        actual_mode = "spatially_tiled"

    if not tiles:
        raise RuntimeError("No processing windows intersect the AOI.")

    # Deterministic folder -> resumable.
    run_key = _run_key(
        process=process,
        items=items,
        start_date=start_date,
        end_date=end_date,
        composite_method=composite_method,
        cloud_cover_threshold=cloud_cover_threshold,
        tile_size_m=tile_size_m,
        target_crs=target_crs,
        aoi_shape=aoi_shape,
        scl_classes=scl_classes,
        processing_mode=actual_mode,
        max_window_size_m=max_window_size_m,
    )

    run_dir = output_dir / "tiles" / f"{process.lower()}_{run_key}"
    run_dir.mkdir(parents=True, exist_ok=True)

    manifest_file = run_dir / "tile_manifest.json"

    # Real footprints (not bboxes) for per-tile scene selection.
    item_footprints = [
        (item, shape(item.geometry), item.to_dict()) for item in items
    ]

    tasks = []
    skipped = []

    for tile in tiles:
        tile_id = tile["tile_id"]

        selected = [
            (item, d)
            for item, footprint, d in item_footprints
            if footprint.intersects(tile["aoi_geometry_wgs84"])
        ]

        if not selected:
            skipped.append({
                "tile_id": tile_id,
                "bounds": list(tile["bounds"]),
                "status": "skipped_no_scenes",
            })
            continue

        tasks.append({
            "tile": tile,
            "item_dicts": [d for _, d in selected],
            "process": process,
            "composite_method": composite_method,
            "target_crs": target_crs,
            "tile_file": str(run_dir / f"{process.lower()}_{tile_id}.tif"),
            "count_file": (
                str(run_dir / f"validcount_{tile_id}.tif")
                if write_valid_count else None
            ),
            "retries": int(tile_retries),
            "scl_classes": list(scl_classes),
        })

    if not tasks:
        raise RuntimeError("No scenes intersect any tile of the AOI.")

    # Avoid starting more worker processes than there are tasks.
    max_workers = min(max(1, int(max_workers)), len(tasks))

    print("\nAOI PROCESSING")
    print("==============")
    print("Product:", process)
    print("Target CRS:", target_crs)
    print("Processing mode:", actual_mode)
    if actual_mode == "single_window":
        print("Window limit:", max_window_size_m, "metres per dimension")
    else:
        print("Tile size:", tile_size_m, "metres")
    print("Windows with data:", len(tasks), "of", len(tiles))
    print("Scenes:", len(items))
    print("Workers:", max_workers)
    print("Run folder:", run_dir)

    header = {
        "product": process,
        "start_date": str(start_date),
        "end_date": str(end_date),
        "composite_method": composite_method,
        "cloud_cover_threshold_percent": float(cloud_cover_threshold),
        "target_crs": str(target_crs),
        "processing_mode": actual_mode,
        "max_window_size_m": max_window_size_m,
        "tile_size_m": tile_size_m,
        "workers": max_workers,
        "scene_ids": [item.id for item in items],
        "run_key": run_key,
    }

    records = list(skipped)
    overall_started = time.perf_counter()
    done = 0

    def _handle(record):
        nonlocal done
        done += 1
        records.append(record)
        print(
            f"[{done}/{len(tasks)}] {record['tile_id']}: "
            f"{record['status']}"
            + (
                f" ({record.get('elapsed_seconds')} s: "
                f"compute {record.get('compute_seconds')} s, "
                f"export {record.get('export_seconds')} s)"
                if record["status"] == "completed" else ""
            )
            + (
                f" - {record['error']}"
                if record["status"] == "failed" else ""
            )
        )
        _write_manifest(
    manifest_file, header, records, "in_progress",
    project_root=project_root,
)

    if max_workers == 1:
        for task in tasks:
            _handle(_process_one_tile(task))
    else:
        context = multiprocessing.get_context("spawn")
        with ProcessPoolExecutor(
            max_workers=max_workers, mp_context=context
        ) as pool:
            futures = [pool.submit(_process_one_tile, t) for t in tasks]
            for future in as_completed(futures):
                _handle(future.result())

    failed = [r for r in records if r["status"] == "failed"]

    if failed:
        _write_manifest(
    manifest_file, header, records, "failed",
    project_root=project_root,
)
        raise RuntimeError(
            f"{len(failed)} tile(s) failed. Completed tiles are kept in "
            f"{run_dir}; re-run with identical inputs to resume. "
            f"First error: {failed[0]['error']}"
        )

    _write_manifest(
    manifest_file, header, records, "tiles_complete",
    project_root=project_root,
)

    tile_files = sorted(
        Path(r["file"]) for r in records if r.get("file")
    )
    count_files = sorted(
        Path(r["count_file"]) for r in records if r.get("count_file")
    )

    # --------------------------------------------------------
    # Mosaic main product
    # --------------------------------------------------------

    with rasterio.open(tile_files[0]) as src:
        tile_nodata = src.nodata
        tile_dtype = np.dtype(src.dtypes[0])

    if tile_nodata is None or np.isnan(tile_nodata):
        nodata_arg = "nan"
    else:
        nodata_arg = str(tile_nodata)

    predictor = "3" if tile_dtype.kind == "f" else "2"

    vrt_file = run_dir / f"{process.lower()}_mosaic.vrt"
    output_file = output_dir / OUTPUT_NAMES[process]

    print("\nBuilding final mosaic...")

    _mosaic(
        tile_files,
        vrt_file,
        output_file,
        nodata_arg=nodata_arg,
        cog_options=[
            "-co", "COMPRESS=ZSTD",
            "-co", f"PREDICTOR={predictor}",
            "-co", "BLOCKSIZE=512",
            "-co", "OVERVIEW_RESAMPLING=AVERAGE",
            "-co", "NUM_THREADS=ALL_CPUS",
            "-co", "BIGTIFF=IF_SAFER",
        ],
        gdalbuildvrt=gdalbuildvrt,
        gdal_translate=gdal_translate,
    )

    valid_cog, errors, warnings = cog_validate(
        str(output_file), strict=True
    )

    print("\nFINAL MOSAIC COG VALIDATION")
    print("Valid COG:", valid_cog)
    print("Errors:", errors)
    print("Warnings:", warnings)

    if not valid_cog:
        raise RuntimeError(
            f"Final mosaic failed strict COG validation: {errors}"
        )

    # A file that exists and passes COG validation can still contain only
    # NoData. Do not report such an output as a successful product.
    with rasterio.open(output_file) as src:
        valid_product_pixels = 0
        for _, window in src.block_windows(1):
            block = src.read(window=window, masked=True)
            values = np.asarray(block.data)
            valid_mask = (
                ~np.ma.getmaskarray(block).any(axis=0)
                & np.isfinite(values).all(axis=0)
            )
            valid_product_pixels += int(valid_mask.sum())

    if valid_product_pixels == 0:
        raise RuntimeError(
            f"NO_VALID_PIXELS: {process} mosaic contains no finite, "
            "unmasked pixels after AOI clipping and SCL masking."
        )

    # --------------------------------------------------------
    # Mosaic valid-observation-count raster
    # --------------------------------------------------------

    valid_count_file = None

    if count_files:
        candidate_count_file = output_dir / "valid_observation_count.tif"

        _mosaic(
            count_files,
            run_dir / "validcount_mosaic.vrt",
            candidate_count_file,
            nodata_arg=str(COUNT_NODATA),
            cog_options=[
                "-co", "COMPRESS=DEFLATE",
                "-co", "PREDICTOR=2",
                "-co", "NUM_THREADS=ALL_CPUS",
                "-co", "OVERVIEW_RESAMPLING=NEAREST",
                "-co", "BIGTIFF=IF_SAFER",
            ],
            gdalbuildvrt=gdalbuildvrt,
            gdal_translate=gdal_translate,
        )

        # Mark the count raster as available only after validating it.
        if not candidate_count_file.is_file():
            raise RuntimeError(
                "Count raster mosaic was not created: "
                f"{candidate_count_file}"
            )

        with rasterio.open(candidate_count_file) as src:
            if src.count != 1:
                raise RuntimeError(
                    "Count raster must have exactly one band; "
                    f"found {src.count}."
                )

            if src.nodata != COUNT_NODATA:
                raise RuntimeError(
                    "Count raster has unexpected NoData value: "
                    f"{src.nodata}; expected {COUNT_NODATA}."
                )

            valid_pixels = 0
            positive_pixels = 0

            for _, window in src.block_windows(1):
                values = src.read(1, window=window, masked=True)
                data = values.compressed()
                valid_pixels += data.size
                positive_pixels += int(np.count_nonzero(data > 0))

            if valid_pixels == 0 or positive_pixels == 0:
                raise RuntimeError(
                    "Count raster contains no positive valid observations."
                )

        valid_count_file = candidate_count_file
    

    # --------------------------------------------------------
    # Metadata
    # --------------------------------------------------------

    mask_stats = {
        "method": "Sentinel-2 SCL",
        "applied_before_temporal_composite": True,
        "scope": "each processing window",
        "retained_scl_classes": list(scl_classes),
        "excluded_scl_classes": excluded_classes_for(scl_classes),
        "per_observation_counts_computed": valid_count_file is not None,
        "valid_observation_count_raster": (
    _portable_path(valid_count_file, project_root)
    if valid_count_file else None
),
    }

    # Generate display previews from the final exported COG.
    # Preview failures must not invalidate an otherwise successful product.
    preview_paths = {}
    preview_error = None
    preview_file = None

    if process in {"RGB", "FALSE_COLOR", "NDWI"}:
        preview_path = output_dir / f"{process.lower()}_preview.png"

        try:
            if process == "NDWI":
                create_ndwi_preview(output_file, preview_path)
            else:
                create_cog_preview(output_file, preview_path, process)
            preview_paths[f"{process.lower()}_preview"] = preview_path
            preview_file = preview_path
        except Exception as exc:
            preview_error = str(exc)
            print(
                f"WARNING: Could not create {process} preview: {exc}"
            )

    masking_comparison = {
        "processing_mode": actual_mode,
        "tile_count": len(tasks),
        "tile_size_m": tile_size_m,
        "before_after_rgb_previews_generated": False,
        "tile_manifest": _portable_path(manifest_file, project_root),
        "preview_generated": bool(preview_paths),
        "preview_error": preview_error,
    }

    metadata = create_metadata(
        output_path=output_file,
        aoi_shape=aoi_shape,
        input_parameters=input_parameters,
        start_date=start_date,
        end_date=end_date,
        cloud_cover_threshold=cloud_cover_threshold,
        items=items,
        reference_item=reference_item,
        composite_method=composite_method,
        process=process,
        mask_stats=mask_stats,
        masking_comparison=masking_comparison,
        project_root=project_root,
        preview_paths=preview_paths,
        valid_count_path=valid_count_file,
        valid_count_created=valid_count_file is not None,
    )

    elapsed = time.perf_counter() - overall_started

    metadata["processing"]["mode"] = actual_mode
    metadata["processing"]["tile_size_m"] = tile_size_m
    metadata["processing"]["tile_count"] = len(tasks)
    metadata["processing"]["tile_manifest"] = _portable_path(
    manifest_file,
    project_root,
)
    metadata["processing"]["workers"] = max_workers
    metadata["processing"]["elapsed_seconds"] = round(elapsed, 3)

    metadata_file = save_metadata(metadata, output_dir / "metadata.json")

    _write_manifest(
    manifest_file, header, records, "completed",
    project_root=project_root,
)


    if not keep_tiles:
        # Remove intermediate tile files but preserve the final manifest.
        for path in run_dir.iterdir():
            if path == manifest_file:
                continue

            if path.is_dir():
                shutil.rmtree(path, ignore_errors=True)
            else:
                path.unlink(missing_ok=True)


    print("\nTILED PROCESSING COMPLETED")
    print("Product:", process)
    print("Mosaic:", output_file)
    print("Metadata:", metadata_file)

    return {
        "output_file": output_file,
        "metadata_file": metadata_file,
        "manifest_file": manifest_file,
        "valid_count_file": valid_count_file,
        "preview_file": preview_file,
        "tile_count": len(tasks),
        "processing_mode": actual_mode,
        "elapsed_seconds": elapsed,
    }
